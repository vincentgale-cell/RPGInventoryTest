import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Oh, Hi! Welcome to my Codehouse!"); //baldi basic reference
        Weapon MetalWaterBottle = new Weapon(); //makes a weapon to test the stuff pertaining to weapons
        Accessory AppleWatch = new Accessory(); //makes an accessory to test the stuff pertaining to accessories
        Consumable Oats = new Consumable(); // makes a consumable to test the stuff pertaining to accessories
        Accessory onlyExistsToDie = new Accessory(); //a silicon sacrifice to show my remove command works
        Bag MainBag = new Backpack(); //a bag to have the hashmap to contain the items
        MainBag.addItem(Oats); //brother i have some oats
        MainBag.addItem(2, Oats); //brother you cannot have more oats
        MainBag.addItem(2, AppleWatch); //hey thats a thing i literally have
        MainBag.addItem(2, MetalWaterBottle); //cant put that there boy
        MainBag.addItem(3, MetalWaterBottle); //can put that there boy
        MainBag.addItem(onlyExistsToDie); //the sacrifice has been placed on its altar
        MainBag.seeItems(); //shows the items (its only the addresses but uhhhh i dont really care rn)
        MainBag.removeItem(onlyExistsToDie); //i told you so
        (MainBag.bagInventory.get(1)).useItem(MainBag.bagInventory.get(1)); //runs the applicable command for the item in slot 1
        (MainBag.bagInventory.get(1)).useItem(MainBag.bagInventory.get(1)); //ditto (different output due to the nature of the applicable command)
        (MainBag.bagInventory.get(2)).useItem(MainBag.bagInventory.get(2)); //ditto
        (MainBag.bagInventory.get(3)).useItem(MainBag.bagInventory.get(3)); //ditto
    }
}
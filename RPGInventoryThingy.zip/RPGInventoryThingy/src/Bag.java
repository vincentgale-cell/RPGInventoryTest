import java.util.HashMap;

public abstract class Bag {
    public Integer capacity;
    public String BagType;
    HashMap<Integer, RPGItem> bagInventory = new HashMap<>();
    public Bag() {
        this.capacity = 10;
        this.BagType = "Generic Bag";
    }
    public void addItem(Integer s, RPGItem t) {
        if (!bagInventory.containsValue(t)) {
            if (bagInventory.get(s) != null) {
                System.out.println("That slot already contains an item.");
            } else {
                this.bagInventory.put(s, t);
                System.out.println("Item placed in empty slot " + s + ".");
            }
        } else {
            System.out.println("That item already exists in your inventory. No duplicates allowed.");
        }
    }
    public void addItem(RPGItem t) {
        if (!bagInventory.containsValue(t)) {
            for (Integer i = 1; i <= this.capacity; i++) {
                if (this.bagInventory.get(i) == null) {
                    this.bagInventory.put(i, t);
                    System.out.println("Item placed in empty slot " + i + ".");
                    break;
                }
            }
        } else {
        System.out.println("That item already exists in your inventory. No duplicates allowed.");
        }
    }
    public void addItem() {
        System.out.println("How did you get past my gemmy input handling? Heckin' hacker! Yuor ar le BANNED!!");
    }
    public void removeItem(Integer s, RPGItem t) {
        this.bagInventory.remove(s, t);
        System.out.println("The item in slot " + s + " has been removed.");
    }
    public void removeItem(RPGItem t) {
        for (Integer i = 1; i <= this.capacity; i++) {
            if (this.bagInventory.get(i) == t) {
                this.bagInventory.remove(i);
                System.out.println("Found item in slot " + i + " and removed it.");
                break;
            }
        }
    }
    public void removeItem(Integer s) {
        this.bagInventory.remove(s);
        System.out.println("The item (if there was one) in slot " + s + " has been removed.");
    }
    public void removeItem() {
        System.out.println("What? No Items? No items, no P A S S");
    }
    public void clearBag() {
        for (Integer i = 1; i <= this.capacity; i++) {
            this.bagInventory.remove(i);
        }
        System.out.println("All of your items have been removed from your bag.");
    }
    public void seeItems() {
        System.out.println("These are all of the items in your inventory (null means there's nothing in that slot):");
        for (Integer i = 1; i <= this.capacity; i++) {
            System.out.println("Slot " + i + ": " + this.bagInventory.get(i));
        }
    }
}

class Satchel extends Bag {
    public Satchel() {
        this.capacity = 5;
        this.BagType = "Satchel";
    }
}

class Backpack extends Bag {
    public Backpack() {
        this.capacity = 15;
        this.BagType = "Backpack";
    }
}

class Carriage extends Bag {
    public Carriage() {
        this.capacity = 25;
        this.BagType = "Carriage";
    }
}
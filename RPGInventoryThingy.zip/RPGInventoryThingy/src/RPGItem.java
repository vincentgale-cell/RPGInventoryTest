public abstract class RPGItem {
    public String ItemType;
    public Integer damageDealt;
    public Boolean usedConsumable;
    public RPGItem() {
        this.ItemType = "Generic Item";
    }
    public void useWeapon() {
        System.out.println("You use your weapon.");
        System.out.println("Congrats. You dealt " + this.damageDealt + " damage to the air.");
    }
    public void flexAccessory() {
        System.out.println("You fidget with your accessory and try to flex it on some unseen being.");
        System.out.println("At least, I can only assume that, because there's nobody around for your to flex it on.");
    }
    public void devourConsumable() {
        if (usedConsumable == false) {
            System.out.println("You scarf down/chug your consumable.");
            this.usedConsumable = true;
            System.out.println("Yummers.");
        } else {
            System.out.println("You reminisce on how delicious that consumable tasted.");
            System.out.println("You already ate it though, and you're really sad you can't eat it again.");
        }
    }
    public void useItem(RPGItem r) {
        switch(r.ItemType) {
        case "Weapon":
            r.useWeapon();
            break;
        case "Accessory":
            r.flexAccessory();
            break;
        case "Consumable":
            r.devourConsumable();
            break;
        case "Generic Item":
            System.out.println("You used your item... whatever it was.");
            break;
        default:
            System.out.println("You probably shouldn't ever see this message.");
            break;
        }
    }
}

class Weapon extends RPGItem {
    public Weapon() {
        this.ItemType = "Weapon";
        this.damageDealt = 3;
    }
    public Weapon(Integer d) {
        this.ItemType = "Weapon";
        this.damageDealt = d;
    }
}

class Accessory extends RPGItem {
    public Accessory() {
        this.ItemType = "Accessory";
    }
}

class Consumable extends RPGItem {
    public Consumable() {
        this.ItemType = "Consumable";
        this.usedConsumable = false;
    }
}